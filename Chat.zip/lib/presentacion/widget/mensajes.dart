import 'dart:html';

import 'package:chat/Domain/entities/message_entitie.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MensajesMios extends StatelessWidget {
  final Message messageText;

  const MensajesMios({super.key, required this.messageText});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          decoration: BoxDecoration(
              color: colors.primary, borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Text(
              messageText.text,
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
        SizedBox(height: 10)
      ],
    );
  }
}
