import 'package:chat/Domain/entities/message_entitie.dart';
import 'package:chat/infraestructure/models/yes_no_models.dart';
import 'package:dio/dio.dart';

class GetYesNoAnswer {
  final _dio = Dio();

  Future<Message> getAnswer() async {
    final Response = await _dio.get('https://yesno.wtf/api');
    final YesNoModel = YesNoModels.fromJsonMap(Response.data);
    return YesNoModel.toMessageEntity();
  }
}
