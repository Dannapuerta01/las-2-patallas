import 'dart:html';
import 'dart:js';
import 'dart:js_util';

import 'package:chat/Domain/entities/message_entitie.dart';
import 'package:chat/presentacion/providers/chat_provider.dart';
import 'package:chat/presentacion/widget/mensajes.dart';
import 'package:chat/presentacion/widget/mensajesdeel.dart';
import 'package:chat/presentacion/widget/shared/message_flied_box.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Chatscreen extends StatelessWidget {
  const Chatscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(5.8),
          child: CircleAvatar(
              backgroundImage: NetworkImage(
                  'https://img.freepik.com/vector-gratis/nina-feliz-mariposa_1450-103.jpg?semt=ais_hybrid&w=740&q=80')),
        ),
        title: Text("chat del amor"),
        centerTitle: true,
      ),
      body: ChatVista(),
    );
  }
}

class ChatVista extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final chatprovider = context.watch<Chatprovider>();
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: chatprovider.chatScrollcontroller,
                itemCount: chatprovider.messageList.length,
                itemBuilder: (context, index) {
                  final message = chatprovider.messageList[index];
                  return (message.fromwho == fromwho.hers)
                      ? Mensajesdeel(msgdeel: message)
                      : MensajesMios(messageText: message);
                },
              ),
            ),
            // widget caja de texto
            MessageBox(
              onValue: (value) => chatprovider.sendMenssage(value),
            ),
          ],
        ),
      ),
    );
  }
}
