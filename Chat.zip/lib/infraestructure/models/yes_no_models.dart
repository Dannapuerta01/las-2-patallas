import 'dart:convert';
import 'dart:html';

import 'package:chat/Domain/entities/message_entitie.dart';
import 'package:flutter/material.dart';

class YesNoModels {
  final String answer; // No-yes
  final bool forced; // True _- false
  final String image; // url image

  YesNoModels(
      {required this.answer, required this.forced, required this.image});

  factory YesNoModels.fromJsonMap(Map<String, dynamic> json) => YesNoModels(
        answer: json["answer"],
        forced: json["forced"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() =>
      {"answer": answer, "forced": forced, "image": image};

  Message toMessageEntity() => Message(
      text: answer == 'yes' ? 'si' : 'no',
      fromwho: fromwho.hers,
      imageUrl: image);
}
