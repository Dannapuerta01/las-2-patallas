import 'package:chat/Domain/entities/message_entitie.dart';
import 'package:chat/config/helpers/get_no_yes_answer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Chatprovider extends ChangeNotifier {
  final ScrollController chatScrollcontroller = ScrollController();
  final GetYesNoAnswer getYesNoAnswer = GetYesNoAnswer();

  List<Message> messageList = [
    Message(text: 'Hola bebe', fromwho: fromwho.mys),
    Message(text: 'Te encuentras bien?', fromwho: fromwho.mys)
  ];

  Future<void> sendMenssage(String text) async {
    if (text.isEmpty) return;

    final newMenssage = Message(text: text, fromwho: fromwho.mys);
    messageList.add(newMenssage);

    if (text.endsWith('?')) {
      await herReply();
    }
    notifyListeners();
    movelScrollToBotton();
  }

  Future<void> herReply() async {
    final herMessage = await getYesNoAnswer.getAnswer();
    messageList.add(herMessage);
    notifyListeners();
    movelScrollToBotton();
  }

  Future<void> movelScrollToBotton() async {
    await Future.delayed(const Duration(microseconds: 100));
    chatScrollcontroller.animateTo(
        chatScrollcontroller.position.maxScrollExtent,
        duration: const Duration(microseconds: 250),
        curve: Curves.easeInExpo);
  }
}
