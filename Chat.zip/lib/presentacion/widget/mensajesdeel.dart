import 'dart:html';

import 'package:chat/Domain/entities/message_entitie.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Mensajesdeel extends StatelessWidget {
  final Message msgdeel;
  const Mensajesdeel({super.key, required this.msgdeel});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
              color: colors.primary, borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Text(
              msgdeel.text,
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
        SizedBox(height: 10),
        _ImageB(msgdeel.imageUrl!),
        SizedBox(height: 10),
      ],
    );
  }
}

class _ImageB extends StatelessWidget {
  final String urlImage;

  const _ImageB(this.urlImage);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Image.network(
        urlImage,
        width: size.width * 0.7,
        height: 150,
        fit: BoxFit.cover,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            width: size.width * 8.7,
            height: 150,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            child: Text('cargando imagen..'),
          );
        },
      ),
    );
  }
}
