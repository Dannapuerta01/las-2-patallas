import 'dart:html';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MessageBox extends StatelessWidget {
  final ValueChanged<String> onValue;
  const MessageBox({super.key, required this.onValue});

  @override
  Widget build(BuildContext context) {
    final TextController = TextEditingController();
    final focusNode = FocusNode();
    final OutlineInput = UnderlineInputBorder(
        borderSide: BorderSide(color: Colors.pink),
        borderRadius: BorderRadius.circular(48));

    return TextFormField(
      onTapOutside: (Event) {
        focusNode.unfocus();
      },
      focusNode: focusNode,
      controller: TextController,
      decoration: InputDecoration(
          hintText: 'Ingresar mensaje',
          filled: true,
          focusedBorder: OutlineInput,
          enabledBorder: OutlineInput,
          suffixIcon: IconButton(
              onPressed: () {
                final textValue = TextController.value.text;

                onValue(textValue);
                TextController.clear();
              },
              icon: Icon(Icons.send_outlined))),
      onFieldSubmitted: (value) {
        onValue(value);
        TextController.clear();
      },
    );
  }
}
