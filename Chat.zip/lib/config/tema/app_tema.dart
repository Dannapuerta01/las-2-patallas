import 'package:flutter/material.dart';

const List<Color> _colorThere = [Colors.purple, Colors.pink, Colors.indigo];

class AppTema {
  final int selectcolor;
  AppTema({this.selectcolor = 2})
      : assert(selectcolor >= 0 && selectcolor <= _colorThere.length - 1,
            'El valor designado no esta en el rango de los colores de la lista debe estar entre 0 y ${_colorThere.length}');
  ThemeData theme() {
    return ThemeData(
        useMaterial3: true, colorSchemeSeed: _colorThere[selectcolor]);
  }
}
